

public class Buffer {

	
	
	public Buffer(int s) {
		//TODO
	}
	
	public void producir(int dato) {
		//TODO			
	}
	
	public int consumir() {
		//TODO
	}
	

}
