
public class Tiovivo {
		
	
	public void subir(int id) 
	{	
	//TODO
	}
	
	public void bajar(int id) 
	{
		//TODO
	}
	
	public void esperaLleno () 
	{
		//TODO			
	}
	
	public void finViaje () 
	{
		//TODO
	}
}
