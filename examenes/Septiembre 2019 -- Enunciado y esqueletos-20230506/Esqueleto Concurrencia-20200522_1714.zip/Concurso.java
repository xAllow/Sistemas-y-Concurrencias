package esqueleto;



public class Concurso {

	
	public void tirarMoneda(int id,boolean cara) throws InterruptedException {
		
		
	}	
	
	public boolean concursoTerminado() {
		
		return false; //borrar
	}
}