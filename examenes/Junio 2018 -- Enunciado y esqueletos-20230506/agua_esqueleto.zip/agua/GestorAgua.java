package agua;


import java.util.concurrent.*;

public class GestorAgua {

	
	
	public void hListo(int id) throws InterruptedException{ 
	}
	
	public void oListo(int id) throws InterruptedException{ 

	}
}